// Restaurant Website JavaScript - Fixed Version
// Handles logo animation timing and menu interactions

class RestaurantApp {
    constructor() {
        this.animationDuration = 3500; // 3.5 seconds for logo animation
        this.transitionDelay = 800; // Additional delay for smooth transition
        this.isAnimationComplete = false;
        
        // Wait for DOM to be fully loaded before selecting elements
        this.initElements();
    }

    initElements() {
        this.elements = {
            landing: document.getElementById('landing'),
            menu: document.getElementById('menu'),
            menuTabs: document.querySelectorAll('.menu-tab'),
            menuCategories: document.querySelectorAll('.menu-category')
        };
        
        // Verify elements exist
        if (!this.elements.landing || !this.elements.menu) {
            console.error('Critical elements not found');
            return;
        }
        
        this.init();
    }

    init() {
        // Ensure landing page is visible initially
        this.elements.landing.style.display = 'flex';
        this.elements.menu.classList.add('hidden');
        
        // Start the application flow
        this.handleInitialAnimation();
        this.setupMenuTabs();
        this.setupAccessibility();
        
        // Add resize listener for responsive adjustments
        window.addEventListener('resize', this.handleResize.bind(this));
    }

    // Handle the initial logo animation and transition to menu
    handleInitialAnimation() {
        // Ensure landing animation starts properly
        const logoAnimation = document.querySelector('.logo-animation');
        if (logoAnimation) {
            logoAnimation.style.animation = 'logoReveal 3.5s cubic-bezier(0.16, 1, 0.3, 1) forwards';
        }
        
        // After animation completes, transition to menu
        setTimeout(() => {
            if (!this.isAnimationComplete) {
                this.isAnimationComplete = true;
                this.transitionToMenu();
            }
        }, this.animationDuration + this.transitionDelay);
    }

    // Smooth transition from landing to menu
    transitionToMenu() {
        // Fade out landing page
        this.elements.landing.classList.add('fade-out');
        
        // After landing fade completes, show menu
        setTimeout(() => {
            this.elements.landing.style.display = 'none';
            this.elements.menu.classList.remove('hidden');
            
            // Trigger menu animation
            requestAnimationFrame(() => {
                this.elements.menu.classList.add('visible');
                this.animateMenuItems('appetizers');
            });
        }, 800); // Match CSS transition duration
    }

    // Setup menu tab functionality - Fixed version
    setupMenuTabs() {
        this.elements.menuTabs.forEach(tab => {
            // Remove any existing listeners to prevent duplicates
            tab.removeEventListener('click', this.handleTabClick);
            
            // Add click listener with proper binding
            tab.addEventListener('click', (e) => {
                e.preventDefault();
                const category = e.target.getAttribute('data-category');
                console.log('Tab clicked:', category); // Debug log
                this.switchCategory(category, e.target);
            });
            
            // Add keyboard navigation
            tab.addEventListener('keydown', (e) => {
                if (e.key === 'Enter' || e.key === ' ') {
                    e.preventDefault();
                    const category = e.target.getAttribute('data-category');
                    this.switchCategory(category, e.target);
                }
            });
        });
    }

    // Switch between menu categories - Fixed version
    switchCategory(categoryName, activeTab) {
        console.log('Switching to category:', categoryName); // Debug log
        
        if (!categoryName) {
            console.error('No category name provided');
            return;
        }

        // Update tab states
        this.elements.menuTabs.forEach(tab => {
            tab.classList.remove('active');
            tab.setAttribute('aria-selected', 'false');
        });
        
        if (activeTab) {
            activeTab.classList.add('active');
            activeTab.setAttribute('aria-selected', 'true');
        }

        // Update category display
        this.elements.menuCategories.forEach(category => {
            category.classList.remove('active');
            category.setAttribute('aria-hidden', 'true');
        });

        const targetCategory = document.getElementById(categoryName);
        if (targetCategory) {
            targetCategory.classList.add('active');
            targetCategory.setAttribute('aria-hidden', 'false');
            this.animateMenuItems(categoryName);
        } else {
            console.error('Target category not found:', categoryName);
        }

        // Announce category change for screen readers
        this.announceToScreenReader(`${this.formatCategoryName(categoryName)} menu selected`);
    }

    // Animate menu items when category switches - Enhanced version
    animateMenuItems(categoryName) {
        const category = document.getElementById(categoryName);
        if (!category) {
            console.error('Category not found for animation:', categoryName);
            return;
        }

        const items = category.querySelectorAll('.menu-item');
        console.log('Animating items for category:', categoryName, 'Items found:', items.length);
        
        // Reset and animate items
        items.forEach((item, index) => {
            // Reset initial state
            item.style.opacity = '0';
            item.style.transform = 'translateY(30px)';
            
            // Stagger the animation
            setTimeout(() => {
                item.style.transition = 'all 0.6s cubic-bezier(0.16, 1, 0.3, 1)';
                item.style.opacity = '1';
                item.style.transform = 'translateY(0)';
            }, index * 150); // Increased delay for better effect
        });
    }

    // Setup accessibility features
    setupAccessibility() {
        // Add ARIA attributes
        this.elements.menuTabs.forEach((tab, index) => {
            tab.setAttribute('role', 'tab');
            tab.setAttribute('aria-selected', tab.classList.contains('active'));
            tab.setAttribute('tabindex', tab.classList.contains('active') ? '0' : '-1');
            tab.setAttribute('id', `tab-${index}`);
        });

        this.elements.menuCategories.forEach((category, index) => {
            category.setAttribute('role', 'tabpanel');
            category.setAttribute('aria-hidden', !category.classList.contains('active'));
            category.setAttribute('aria-labelledby', `tab-${index}`);
        });

        // Create live region for announcements
        this.createLiveRegion();
        
        // Add keyboard navigation between tabs
        this.setupKeyboardNavigation();
    }

    // Setup keyboard navigation for tabs
    setupKeyboardNavigation() {
        this.elements.menuTabs.forEach((tab, index) => {
            tab.addEventListener('keydown', (e) => {
                let targetIndex;
                
                switch (e.key) {
                    case 'ArrowRight':
                    case 'ArrowDown':
                        e.preventDefault();
                        targetIndex = (index + 1) % this.elements.menuTabs.length;
                        break;
                    case 'ArrowLeft':
                    case 'ArrowUp':
                        e.preventDefault();
                        targetIndex = (index - 1 + this.elements.menuTabs.length) % this.elements.menuTabs.length;
                        break;
                    case 'Home':
                        e.preventDefault();
                        targetIndex = 0;
                        break;
                    case 'End':
                        e.preventDefault();
                        targetIndex = this.elements.menuTabs.length - 1;
                        break;
                }
                
                if (targetIndex !== undefined) {
                    const targetTab = this.elements.menuTabs[targetIndex];
                    targetTab.focus();
                    const category = targetTab.getAttribute('data-category');
                    this.switchCategory(category, targetTab);
                }
            });
        });
    }

    // Create ARIA live region for screen reader announcements
    createLiveRegion() {
        // Remove existing live region if it exists
        const existingLiveRegion = document.getElementById('live-region');
        if (existingLiveRegion) {
            existingLiveRegion.remove();
        }
        
        const liveRegion = document.createElement('div');
        liveRegion.setAttribute('aria-live', 'polite');
        liveRegion.setAttribute('aria-atomic', 'true');
        liveRegion.className = 'sr-only';
        liveRegion.id = 'live-region';
        document.body.appendChild(liveRegion);
    }

    // Announce messages to screen readers
    announceToScreenReader(message) {
        const liveRegion = document.getElementById('live-region');
        if (liveRegion) {
            liveRegion.textContent = message;
            
            // Clear after announcement
            setTimeout(() => {
                liveRegion.textContent = '';
            }, 1000);
        }
    }

    // Format category names for better readability
    formatCategoryName(categoryName) {
        const formatted = {
            'appetizers': 'Appetizers',
            'mains': 'Main Courses',
            'desserts': 'Desserts',
            'beverages': 'Beverages'
        };
        return formatted[categoryName] || categoryName;
    }

    // Handle responsive adjustments
    handleResize() {
        // Debounce resize events
        clearTimeout(this.resizeTimeout);
        this.resizeTimeout = setTimeout(() => {
            this.adjustForViewport();
        }, 250);
    }

    // Adjust layout for different viewport sizes
    adjustForViewport() {
        const isMobile = window.innerWidth < 768;
        const menuItems = document.querySelectorAll('.menu-item');
        
        // Adjust animation timing for mobile
        if (isMobile) {
            menuItems.forEach((item, index) => {
                item.style.animationDelay = `${index * 50}ms`;
            });
        } else {
            menuItems.forEach((item, index) => {
                item.style.animationDelay = `${index * 100}ms`;
            });
        }
    }

    // Method to handle potential menu data loading (for future Google Docs integration)
    // REPLACE: Menu data source - connect to Google Docs API
    async loadMenuData() {
        try {
            // Placeholder for Google Docs API integration
            console.log('Menu data loading functionality - ready for Google Docs API integration');
        } catch (error) {
            console.error('Error loading menu data:', error);
            this.announceToScreenReader('Menu loading failed. Please refresh the page.');
        }
    }
}

// Enhanced hover effect management
function enhanceHoverEffects() {
    const menuItems = document.querySelectorAll('.menu-item');
    
    menuItems.forEach(item => {
        const placeholder = item.querySelector('.image-placeholder');
        
        item.addEventListener('mouseenter', () => {
            item.style.transform = 'translateY(-8px)';
            item.style.boxShadow = '0 20px 25px -5px rgba(0, 0, 0, 0.1), 0 10px 10px -5px rgba(0, 0, 0, 0.04)';
            
            if (placeholder) {
                placeholder.style.transform = 'scale(1.15) rotate(8deg)';
            }
        });
        
        item.addEventListener('mouseleave', () => {
            item.style.transform = 'translateY(0)';
            item.style.boxShadow = '';
            
            if (placeholder) {
                placeholder.style.transform = 'scale(1) rotate(0deg)';
            }
        });
    });
}

// Performance optimization: Preload critical resources
function preloadResources() {
    // Preload fonts
    const fontLinks = document.querySelectorAll('link[href*="fonts.googleapis.com"]');
    fontLinks.forEach(link => {
        const preloadLink = document.createElement('link');
        preloadLink.rel = 'preload';
        preloadLink.as = 'style';
        preloadLink.href = link.href;
        document.head.appendChild(preloadLink);
    });
}

// Handle loading states and errors
function handlePageLoad() {
    // Remove any loading states
    document.body.classList.add('loaded');
    
    // Initialize the application
    window.restaurantApp = new RestaurantApp();
    
    // Enhance hover effects after DOM is ready
    setTimeout(() => {
        enhanceHoverEffects();
    }, 100);
}

// Initialize when DOM is loaded
function initializeApp() {
    preloadResources();
    handlePageLoad();
    
    // Ensure fonts are loaded before starting animations
    if (document.fonts) {
        document.fonts.ready.then(() => {
            document.body.classList.add('fonts-loaded');
        });
    }
}

// Multiple initialization methods to ensure the app starts
if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', initializeApp);
} else {
    // DOM is already loaded
    initializeApp();
}

// Fallback initialization
setTimeout(() => {
    if (!window.restaurantApp) {
        console.log('Fallback initialization triggered');
        initializeApp();
    }
}, 1000);

// Handle page visibility changes
document.addEventListener('visibilitychange', () => {
    if (document.hidden) {
        document.body.classList.add('paused');
    } else {
        document.body.classList.remove('paused');
    }
});

// Export for potential module use
if (typeof module !== 'undefined' && module.exports) {
    module.exports = RestaurantApp;
}